import os
from launch import LaunchDescription
from launch.actions import ExecuteProcess

def generate_launch_description():

    # Command to launch slam_toolbox with async parameters
    slam_toolbox_command = [
        'ros2', 'launch', 'slam_toolbox', 'online_async_launch.py',
        'params_file:=src/robot_simulation/config/mapper_params_online_async.yaml',
        'use_sim_time:=true'
    ]

    slam_toolbox_node = ExecuteProcess(
        cmd=slam_toolbox_command,
        output='screen'
    )

    return LaunchDescription([
        slam_toolbox_node,
    ])