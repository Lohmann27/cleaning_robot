import os
from launch import LaunchDescription
from launch.actions import ExecuteProcess


def generate_launch_description():

    # Command to launch slam_toolbox with async parameters
    navigation_command = [
        'ros2', 'launch', 'nav2_bringup', 'navigation_launch.py',
        'use_sim_time:=true'
    ]

    navigation_node = ExecuteProcess(
        cmd=navigation_command,
        output='screen'
    )

    return LaunchDescription([
        navigation_node,
    ])