/*
 * Handling of data items - i.e. messages
 * 
 #***************************************************************************
 #*   Copyright (C) 2017-2023 by DTU
 #*   jca@elektro.dtu.dk
 #*
 #*
 #* The MIT License (MIT)  https://mit-license.org/
 #*
 #* Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 #* and associated documentation files (the “Software”), to deal in the Software without restriction,
 #* including without limitation the rights to use, copy, modify, merge, publish, distribute,
 #* sublicense, and/or sell copies of the Software, and to permit persons to whom the Software
 #* is furnished to do so, subject to the following conditions:
 #*
 #* The above copyright notice and this permission notice shall be included in all copies
 #* or substantial portions of the Software.
 #*
 #* THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 #* INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 #* PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE
 #* FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 #* ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 #* THE SOFTWARE. */

#ifndef UDATAITEM_H
#define UDATAITEM_H

#include <mutex>
#include <vector>

#include "userverport.h"
#include "usubscribe.h"
#include "ulogfile.h"

#define MAX_PRIORITY 6
#define MAX_ITEM_KEY_LENGTH 16
// extra client is command line
#define EXTRA_CLIENTS       1
#define MAX_CLIENTS         (MAX_SOCKET_CLIENTS + EXTRA_CLIENTS)

class UBridge;
class UHandler;
class UTeensy;

class UDataItem : public ULogFile
{
public:
  /** constructor */
  UDataItem(const char * key, USource * from, UServerPort * servPtr, const char * createdLogPath, UHandler * responceHandler);
  /** destructor */
  ~UDataItem();
  // descriptive name for this data item
  std::string itemDescription;
  // keyword (tag) for this message,
  // and also make space for string terminator  
  char itemKey[MAX_ITEM_KEY_LENGTH + 1];
  // value string
  std::string itemParams;
  // source update time for item
  UTime itemTime;
  // has data ever been updated
  bool itemValid;
  /**
   * simple update count */
  int updateCnt;
  /**
   * Update interval, time since last update (in seconds) */
  float updateInterval;
  // source of last update
  USource * source = nullptr;
  
  
protected:
  /**
   * pointer so socket server */
  UServerPort * serv;
  // avoid sending and updating at the same time
  std::mutex lock;
  // Relay to client default priority
  int clientDefPriority;
  // logfile
//   ULogFile * logfile;
  // pointer to log-path stored elsewhere
//   const char * logPath;
  // handler if an update involves handling by this bridge itself
  UHandler * handler;
  // list of subscribers to this item
  std::vector<USubscribe*> subs;   
  
  
public:
  /**
   * Setting new source data 
   * \param newData is the data string
   * \param cmdSource is the source of the message
   */
//   void updateItem(const char * key, const char * params, USource * cmdSource);
//   /**
//    * getting stored data or modify subscription or log
//    * \param params are potential commands for this data item
//    * \param msgSource is the source of the message
//    * \param newItem if true, then also test for meta commands - relevant for data source -2 only (Teensy)
//    */
  void handleData(const char * params, USource * msgSource);
  /**
   * returns true, if a reserved keyword for data management is found (e.g. openLog */
  static bool reservedKeyword(const char * msg);
  /**
   * Set new priority from this client
   * \param client is client number from server
   * \param interval set update interval 0=stop, -1=all, 1.. is shortest interval in ms.
   * */
  void setMinimumInterval(USource * client, int intervalMs); //, UTeensy * rob);
  /**
   * Set new priority from this client
   * \param client is client number from server
   * \param interval set update interval 0=stop, -1=all, 1.. is shortest interval in ms.
   * */
  void setOnUpdate(USource * client, int intervalMs, const char * action); //, UTeensy * rob);
  /**
   * Check time to send this message */
  void tick();
  /**
   * Get data item status */
  bool match(const char * item, USource * itemSource);
  /**
   * print status to console */
  void printStatus(bool justSubs);
  /**
   * Stop any subscriptions from this client */
  void stopSubscription(int client);
protected:
  /**
   * get reference to client */
  USubscribe * findSubscriber(USource * client);
  /**
   * Send message to client
   * */
  void sendTo(USource * client);
  /**
   * Send meta information of data item */
  void sendMetaTo(USource * clientIdx);
  
  private:
  /** send item status to this client
   * \param client is index to client to get the status */
  void sendStatus(USource * client);
  /**
   * stop any subscriptions from this client (client lost) */
  void stopClientSubscription(USource * client);
  
};

#endif
