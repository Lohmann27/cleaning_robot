#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist

class WallFollower(Node):
    def __init__(self):
        super().__init__('wall_follower')
        self.publisher_ = self.create_publisher(Twist, 'cmd_vel_wall', 10)
        self.subscription = self.create_subscription(
            LaserScan,
            'scan',
            self.laser_callback,
            10)
        self.subscription  # prevent unused variable warning

        # Parameters for wall following
        self.target_distance = 0.5  # Desired distance from the wall (meters)
        self.linear_speed = 0.2  # Constant forward speed
        self.kp_angular = 1.0  # Proportional gain for angular speed

    def laser_callback(self, msg):
        # Assume the laser scanner has 360 degrees coverage
        # We are interested in the distance to the right side of the robot
        right_distances = msg.ranges[270:360]  # Extract right side readings
        right_distance = min(right_distances)  # Get the minimum distance on the right

        # Calculate the error between desired distance and actual distance
        error = self.target_distance - right_distance

        # Proportional control for steering
        twist_msg = Twist()
        twist_msg.linear.x = self.linear_speed
        twist_msg.angular.z = self.kp_angular * error

        # Publish velocity command
        self.publisher_.publish(twist_msg)

def main(args=None):
    rclpy.init(args=args)
    wall_follower = WallFollower()
    rclpy.spin(wall_follower)

    # Destroy the node explicitly (optional)
    wall_follower.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()